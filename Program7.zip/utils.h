#ifndef UTILS_H
#define UTILS_H

#include <QDebug>

#include <GL/gl.h>
// #include <GL/glu.h>

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/normal.hpp>

enum Attributes{
    position = 0,
    color = 1,
    normal = 2,
    uv1 = 7,
};

inline void PRINT_GL_ERRORS(QString mess)
{
    GLenum err;
    while( (err=glGetError()) != GL_NO_ERROR)
        qDebug() << "GL ERROR: " << mess << err << "(" << err <<")";
}


class Camera {
public:
    glm::vec3 pos;
    glm::vec3 forward;
    glm::vec3 up;
    float yaw;
    float pitch;

    glm::mat4 matrix()
    {
        glm::mat4 m = glm::translate(glm::mat4(1.0), glm::vec3(-pos.x, -pos.y, -pos.z));

        glm::mat4 r = glm::mat4(1.0);

        glm::vec3 s = glm::cross(up, forward);

        m[0] = glm::vec4(s.x, up.x, -forward.x, 0.0f);
        m[1] = glm::vec4(s.y, up.y, -forward.y, 0.0f);
        m[2] = glm::vec4(s.z, up.z, -forward.z, 0.0f);
        m[3] = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);

        return glm::transpose(m * r);
    }
};

class Frame{
public:
    glm::vec3 pos;
    glm::vec3 up;
    glm::vec3 forward;

    glm::mat4 matrix() {
        glm::vec3 s = glm::normalize(glm::cross(up, -forward));

        return glm::mat4(
            glm::vec4(s, 0.0f),
            glm::vec4(up, 0.0f),
            glm::vec4(-forward, 0.0f),
            glm::vec4(pos, 1.0f)
            );
    }
};

#endif // UTILS_H
