#ifndef UTILS_H
#define UTILS_H

#include <QDebug>
#include <windows.h>
#include <GL/gl.h>
#include <GL/glu.h>

#include "glm/glm.hpp"
#include "glm/gtc/matrix_transform.hpp"
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtx/normal.hpp>

enum class Attributes{
    position = 0,
    color = 1,
    normal = 2,
    uv1 = 7,
};

inline void PRINT_GL_ERRORS(QString mess)
{
    GLenum err;
    while( (err=glGetError()) != GL_NO_ERROR)
        qDebug() << "GL ERROR: " << mess << err << (const char*)gluErrorString(err) << "(" << err <<")";
}


class Camera {
public:
    glm::vec3 pos;
    glm::vec3 forward;
    glm::vec3 up;
    glm::mat4 res;
    glm::mat4 matrix()
    {
        glm::mat4 m = glm::translate(glm::mat4(1.0), glm::vec3(-pos.x, -pos.y, -pos.z));
        glm::mat4 r = glm::mat4(1.0);
        glm::vec3 s = glm::cross(up, forward);
        m[0] = glm::vec4(s.x, up.x, -forward.x, 0.0f);
        m[1] = glm::vec4(s.y, up.y, -forward.y, 0.0f);
        m[2] = glm::vec4(s.z, up.z, -forward.z, 0.0f);
        m[3] = glm::vec4(0.0f, 0.0f, 0.0f, 1.0f);
        res = glm::transpose(m * r);
        return res;
    }
};

class Frame{
public:
    glm::vec3 pos;
    glm::vec3 up;
    glm::vec3 forward;
    glm::mat4 matrix() {
        glm::vec3 s = glm::cross(forward, up);
        return glm::mat4(
            s.x, up.x, forward.x, pos.x,
            s.y, up.y, forward.y, pos.y,
            s.z, up.z, forward.z, pos.z,
            0.0f, 0.0f, 0.0f, 1.0f
            );
    }
};

#endif // UTILS_H
