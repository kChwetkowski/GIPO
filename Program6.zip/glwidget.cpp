#include "glwidget.h"
#include "primitives.h"
#include <QDebug>

GLWidget::GLWidget() {
    anglea = 0.0f;
    angleb = 0.0f;
    camera.pos = glm::vec3(0, 0, -2);
    camera.forward = glm::vec3(0, 0, 1);
    camera.up = glm::vec3(0, 1, 0);
}

void GLWidget::initializeGL()
{
    initializeOpenGLFunctions();

    programs["basic_shader"] = new GLSLProgram();
    programs["basic_shader"]->compileShaderFromFile("shaders/shader.vert", GL_VERTEX_SHADER);
    programs["basic_shader"]->compileShaderFromFile("shaders/shader.frag", GL_FRAGMENT_SHADER);
    programs["basic_shader"]->link();

    geometries["axes"] = create_global_axes(1.0f);

    geometries["plane"] = new Geometry();
    geometries["plane"]->primitiveMode = GL_TRIANGLES;
    glm::vec3 plane_verts[] = {
        {-0.1f,  0.1f, 0},
        { 0.1f,  0.1f, 0},
        { 0.1f, -0.1f, 0},
        {-0.1f, -0.1f, 0}
    };
    glm::vec3 plane_colors[] = {{1,1,1}, {1,1,1}, {1,1,1}, {1,1,1} };
    uint plane_idxs[] = {0, 3, 1, 1, 3, 2};
    geometries["plane"]->setVertices(0, plane_verts, 4);
    geometries["plane"]->setAttribute(1, plane_colors, 4);
    geometries["plane"]->setIndices(plane_idxs, 6);

    timer.setInterval(10);
    connect(&timer, SIGNAL(timeout()), this, SLOT(update()));
    timer.start();

    PRINT_GL_ERRORS("Widget::initializeGL(): ");
}


void GLWidget::resizeGL(int w, int h)
{
    glViewport(0,0,w,h);
    float aspect = static_cast<float>(w) / h;
    ProjMat = glm::perspective(glm::radians(60.0f), aspect, 0.1f, 10.0f);
}

void GLWidget::mouseMoveEvent(QMouseEvent *event)
{
    int deltaX = event->pos().x()- lastPos.x();
    int deltaY = event->pos().y() - lastPos.y() ;

    float sensitivity = 0.1f;
    float horizontalAngle = deltaX * sensitivity;
    float verticalAngle = deltaY * sensitivity;

    // Horizontal rotation (oś Y)
    glm::mat4 horizontalRotation = glm::rotate(glm::mat4(1.0f),
                                               glm::radians(horizontalAngle),
                                               glm::vec3(0, 1, 0));
    camera.forward = glm::normalize(glm::vec3(horizontalRotation * glm::vec4(camera.forward, 0.0f)));
    camera.up = glm::normalize(glm::vec3(horizontalRotation * glm::vec4(camera.up, 0.0f)));

    // Vertical rotation (oś X)
    glm::vec3 right = glm::normalize(glm::cross(camera.forward, camera.up));
    glm::mat4 verticalRotation = glm::rotate(glm::mat4(1.0f), glm::radians(verticalAngle), right);
    camera.forward = glm::normalize(glm::vec3(verticalRotation * glm::vec4(camera.forward, 0.0f)));
    camera.up = glm::normalize(glm::vec3(verticalRotation * glm::vec4(camera.up, 0.0f)));

    lastPos = event->pos();
}




void GLWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        lastPos = event->pos();
    }
}


void GLWidget::keyPressEvent(QKeyEvent *e)
{
    key_pressed.insert(e->key());
}

void GLWidget::keyReleaseEvent(QKeyEvent *e)
{
    key_pressed.remove(e->key());
}

void GLWidget::process_keys()
{
    float speed_modifier = 0.01f;

    if (key_pressed.contains(Qt::Key_W)) {
        camera.pos += speed_modifier * camera.forward;
        qDebug() << "Camera position after moving forward: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_S)) {
        camera.pos -= speed_modifier * camera.forward;
        qDebug() << "Camera position after moving backward: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_A)) {
        camera.pos -= speed_modifier * glm::normalize(glm::cross(camera.forward, camera.up));
        qDebug() << "Camera position after moving left: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_D)) {
        camera.pos += speed_modifier * glm::normalize(glm::cross(camera.forward, camera.up));
        qDebug() << "Camera position after moving right: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_Q)) {
        camera.pos += speed_modifier * camera.up;
        qDebug() << "Camera position after moving up: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_Z)) {
        camera.pos -= speed_modifier * camera.up;
        qDebug() << "Camera position after moving down: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }

    ViewMat = glm::lookAt(camera.pos, camera.pos + camera.forward, camera.up);
}


void GLWidget::paintGL()
{
    process_keys();
    glClearColor(0.5, 0.5, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    programs["basic_shader"]->use();
    programs["basic_shader"]->setUniform("ViewMat", ViewMat);
    programs["basic_shader"]->setUniform("ProjectionMat", ProjMat);

    programs["basic_shader"]->setUniform("ModelMat", glm::mat4(1.0f));
    geometries["axes"]->render();

    glm::mat4 MV = glm::mat4(1.0);
    glm::mat4 tr = glm::translate(MV, glm::vec3(0.5, 0, 0));
    // glm::mat4 rota = glm::rotate(MV, anglea / 10.0f, glm::vec3(0, 0, 1));
    // MV = rota * tr;

    // Obrót obiektu wokół własnej osi
    glm::mat4 selfRotate = glm::rotate(MV, glm::radians(angleb), glm::vec3(0, 0, 1));
    // Obrót wokół środka układu współrzędnych
    glm::mat4 orbitRotate = glm::rotate(MV, glm::radians(anglea), glm::vec3(0, 0, 1));
    MV = orbitRotate * tr * selfRotate;

    programs["basic_shader"]->setUniform("ModelMat", MV);
    geometries["plane"]->render();

    anglea++;
    angleb++;

    PRINT_GL_ERRORS("Widget::paintGL(): ");
}

