#ifndef GLWIDGET_H
#define GLWIDGET_H

#include "glslprogram.h"
#include "geometry.h"
#include "utils.h"

#if QT_VERSION_MAJOR >= 6
    #include <QtOpenGLWidgets/QOpenGLWidget>
#else
    #include <QOpenGLWidget>
#endif

#include <QOpenGLFunctions_3_3_Core>
#include <QMap>
#include <QDebug>
#include <QTimer>
#include <QKeyEvent>
// #include "mathgl.h"

#include <texture2d.h>

class GLWidget : public QOpenGLWidget, protected QOpenGLFunctions_3_3_Core
{
private:
    QMap<QString, GLSLProgram*> programs;
    QMap<QString, Geometry*> geometries;
    QMap<QString, Texture2D*> textures;
    QMap<QString, glm::mat4> geometryMat;
    QMap<QString, Frame> frames;


    glm::mat4 MVMat;
    glm::mat4 ModelMat;
    glm::mat4 ViewMat;
    glm::mat4 ProjMat;
    glm::vec3 lightPos;
    float anglea, angleb;
    float angler = 66;
    QTimer timer;

    QSet<int> key_pressed;

    void process_keys();
    QPoint lastPos;

    Camera camera;
    glm::mat4 perspective_mat;

    void createGeometry();
    void createTextures();
    void createShader();

    void updateLightPosition();

protected:
    void initializeGL();
    void paintGL();
    void resizeGL(int w, int h);

    void mouseMoveEvent(QMouseEvent*);
    void mousePressEvent(QMouseEvent*);

    void keyPressEvent(QKeyEvent*);
    void keyReleaseEvent(QKeyEvent*);
public:
    GLWidget();
};


#endif // GLWIDGET_H
