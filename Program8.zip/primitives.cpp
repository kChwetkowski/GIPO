#include "primitives.h"
#include "utils.h"

Geometry *create_axes(float length)
{
    Geometry *g = new Geometry();
    g->primitiveMode = GL_LINES;
    glm::vec3 verts[] = { {0,0,0}, {length,0,0}, {0,0,0}, {0,0.5,0}, {0,0,0}, {0,0,0.5} };
    glm::vec3 colors[] = { {1,0,0}, {1,0,0},  {0,1,0}, {0,1,0},   {0,0,1}, {0,0,1} };
    g->setVertices(0, verts, 6);
    g->setAttribute(1, colors, 6);
    return g;
}

Geometry *create_plane(float w, float h)
{
    Geometry *g = new Geometry();
    g->primitiveMode = GL_TRIANGLES;
    glm::vec3 plane_verts[] = {{-w/2.0f,  h/2.0f,0},
                          { w/2.0f,  h/2.0f,0},
                          { w/2.0f, -h/2.0f,0},
                          {-w/2.0f, -h/2.0f,0}};
    glm::vec3 plane_colors[] = {{1,1,1}, {1,1,1}, {1,1,1}, {1,1,1} };
    uint plane_idxs[] = {0,3,1,    1,3,2};
    g->setVertices(0, plane_verts, 4);
    g->setAttribute(1, plane_colors, 4);
    g->setIndices(plane_idxs, 6);
    return g;
}

Geometry* create_global_axes(float length)
{
    Geometry* g = new Geometry();
    g->primitiveMode = GL_LINES;
    glm::vec3 verts[] = {
        {0, 0, 0}, {length, 0, 0},  // X
        {0, 0, 0}, {0, length, 0},  // Y
        {0, 0, 0}, {0, 0, length}   // Z
    };
    glm::vec3 colors[] = {
        {1, 0, 0}, {1, 0, 0},  // R
        {0, 1, 0}, {0, 1, 0},  // G
        {0, 0, 1}, {0, 0, 1}   // B
    };
    g->setVertices(0, verts, 6);
    g->setAttribute(1, colors, 6);
    return g;
}

Geometry* createTerrainGeometry(int width, int height, const float* elevationData)
{
    Geometry* terrain = new Geometry();
    terrain->primitiveMode = GL_TRIANGLES;

    std::vector<glm::vec3> vertices;
    std::vector<glm::vec2> uv;
    std::vector<uint> indices;

    for (int y = 0; y < height; ++y)
    {
        for (int x = 0; x < width; ++x)
        {
            const float vx = -height/2.0f + height*y/(float)height;
            const float vy = elevationData[y * width + x] * 10.0f;
            const float vz = -width/2.0f + width*x/(float)width;

            vertices.push_back(glm::vec3(vx, vy, vz));

            uv.push_back(glm::vec2((float)x / width, (float)y / height));
        }
    }

    for (int z = 0; z < height - 1; ++z) {
        for (int x = 0; x < width - 1; ++x) {
            unsigned int IndexBottomLeft = z * width + x;
            unsigned int IndexTopLeft = (z + 1) * width + x;
            unsigned int IndexTopRight = (z + 1) * width + x + 1;
            unsigned int IndexBottomRight = z * width + x + 1;

            // Add top left triangle
            indices.push_back(IndexBottomLeft);
            indices.push_back(IndexTopLeft);
            indices.push_back(IndexTopRight);

            // Add bottom right triangle
            indices.push_back(IndexBottomLeft);
            indices.push_back(IndexTopRight);
            indices.push_back(IndexBottomRight);
        }
    }

    // Przypisywanie danych do obiektu Geometry
    terrain->setVertices(Attributes::position, vertices.data(), vertices.size());
    terrain->setAttribute(Attributes::uv1, uv.data(), uv.size());
    terrain->setIndices(indices.data(), indices.size());

    return terrain;
}
