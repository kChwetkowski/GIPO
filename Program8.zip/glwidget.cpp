#include "glwidget.h"
#include "primitives.h"
#include "texture2d.h"
#include <QDebug>

GLWidget::GLWidget() {
    camera.pos = glm::vec3(0, 100, 0);
    camera.forward = glm::vec3(0, 0, 1);
    camera.up = glm::vec3(0, 1, 0);
}



void GLWidget::resizeGL(int w, int h)
{
    glViewport(0, 0, w, h);
    float aspect = static_cast<float>(w) / h;
    ProjMat = glm::perspective(glm::radians(60.0f), aspect, 0.1f, 1000.0f);
}


void GLWidget::createGeometry()
{
    QImage image("textures/clouds2.png");
    int width = image.width();
    int height = image.height();

    std::vector<float> elevationData(width * height);
    for(int y = 0; y < height; ++y)
    {
        for(int x = 0; x < width; ++x)
        {
            elevationData[x + y * width] = qBlue(image.pixel(x, y)) / 255.0f;
        }
    }

    geometries["terrain"] = createTerrainGeometry(width, height, elevationData.data());
    geometryMat["terrain"] = glm::mat4(1.0f);
    frames["terrain"] = Frame();
}

void GLWidget::createTextures()
{
    textures["base_tex"] = new Texture2D;
    if (!textures["base_tex"]->loadFromFile("textures/grass_2k.jpg"))
        qDebug() << "blad tekstury";
}

void GLWidget::createShader()
{
    programs["terrain_shader"] = new GLSLProgram();
    programs["terrain_shader"]->compileShaderFromFile("shaders/tex_base.vert", GL_VERTEX_SHADER);
    programs["terrain_shader"]->compileShaderFromFile("shaders/tex_base.frag", GL_FRAGMENT_SHADER);
    programs["terrain_shader"]->link();
}

void GLWidget::initializeGL()
{
    initializeOpenGLFunctions();

    createShader();
    createGeometry();
    createTextures();

    glEnable(GL_DEPTH_TEST);

    timer.setInterval(10);
    connect(&timer, SIGNAL(timeout()), this, SLOT(update()));
    timer.start();

    ViewMat = glm::lookAt(camera.pos, camera.pos + camera.forward, camera.up);

    PRINT_GL_ERRORS("Widget::initializeGL(): ");
}

void GLWidget::mouseMoveEvent(QMouseEvent *event)
{
    int deltaX = event->pos().x()- lastPos.x();
    int deltaY = event->pos().y() - lastPos.y() ;

    float sensitivity = 0.1f;
    float horizontalAngle = deltaX * sensitivity;
    float verticalAngle = deltaY * sensitivity;

    // Horizontal rotation (oś Y)
    glm::mat4 horizontalRotation = glm::rotate(glm::mat4(1.0f),
                                               glm::radians(horizontalAngle),
                                               glm::vec3(0, 1, 0));
    camera.forward = glm::normalize(glm::vec3(horizontalRotation * glm::vec4(camera.forward, 0.0f)));
    camera.up = glm::normalize(glm::vec3(horizontalRotation * glm::vec4(camera.up, 0.0f)));

    // Vertical rotation (oś X)
    glm::vec3 right = glm::normalize(glm::cross(camera.forward, camera.up));
    glm::mat4 verticalRotation = glm::rotate(glm::mat4(1.0f), glm::radians(verticalAngle), right);
    camera.forward = glm::normalize(glm::vec3(verticalRotation * glm::vec4(camera.forward, 0.0f)));
    camera.up = glm::normalize(glm::vec3(verticalRotation * glm::vec4(camera.up, 0.0f)));

    lastPos = event->pos();
}


void GLWidget::mousePressEvent(QMouseEvent *event)
{
    if (event->button() == Qt::LeftButton) {
        lastPos = event->pos();
    }
}

void GLWidget::keyPressEvent(QKeyEvent *e)
{
    key_pressed.insert(e->key());
}

void GLWidget::keyReleaseEvent(QKeyEvent *e)
{
    key_pressed.remove(e->key());
}

void GLWidget::process_keys()
{
    float speed_modifier = 1.1f;

    if (key_pressed.contains(Qt::Key_W)) {
        camera.pos += speed_modifier * camera.forward;
        // qDebug() << "Camera position after moving forward: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_S)) {
        camera.pos -= speed_modifier * camera.forward;
        // qDebug() << "Camera position after moving backward: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_A)) {
        camera.pos -= speed_modifier * glm::normalize(glm::cross(camera.forward, camera.up));
        // qDebug() << "Camera position after moving left: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_D)) {
        camera.pos += speed_modifier * glm::normalize(glm::cross(camera.forward, camera.up));
        // qDebug() << "Camera position after moving right: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_Q)) {
        camera.pos += speed_modifier * camera.up;
        // qDebug() << "Camera position after moving up: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }
    if (key_pressed.contains(Qt::Key_Z)) {
        camera.pos -= speed_modifier * camera.up;
        // qDebug() << "Camera position after moving down: " << camera.pos.x << camera.pos.y << camera.pos.z;
    }

    ViewMat = glm::lookAt(camera.pos, camera.pos + camera.forward, camera.up);
}


void GLWidget::paintGL()
{
    process_keys();
    glClearColor(0.5, 0.5, 1.0, 1.0);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    textures["base_tex"]->bind(0);
    programs["terrain_shader"]->use();
    programs["terrain_shader"]->setUniform("ModelMat", geometryMat["terrain"]);
    programs["terrain_shader"]->setUniform("ViewMat", ViewMat);
    programs["terrain_shader"]->setUniform("ProjMat", ProjMat);
    geometries["terrain"]->render();
    textures["base_tex"]->unbind();

    PRINT_GL_ERRORS("Widget::paintGL(): ");
}
